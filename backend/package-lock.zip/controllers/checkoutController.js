const Cart = require("../model/Cart");
const Product = require("../model/Product");
const Order = require("../model/Order");

const checkout = async (req, res) => {
  try {
    const { cartId } = req.params;
    const { delivery } = req.body;

    if (!delivery) {
      return res
        .status(400)
        .json({ message: "Missing delivery details" });
    }

    const cart = await Cart.findOne({ cartId });

    if (!cart) {
      return res
        .status(404)
        .json({ message: "Cart not found" });
    }

    if (!cart.items.length) {
      return res
        .status(400)
        .json({ message: "Cart is empty" });
    }

    // VALIDATE PRODUCTS
    const items = [];

    for (const ci of cart.items) {
      const product = await Product.findById(
        ci.productId
      );

      if (!product) {
        return res
          .status(404)
          .json({ message: "Product not found" });
      }

      if (product.outOfStock) {
        return res.status(400).json({
          message: `Product out of stock: ${product.name}`,
        });
      }

      items.push({
        productId: product._id,
        nameSnapshot: product.name,
        priceSnapshot: product.price,
        quantity: ci.quantity,
        imageUrlSnapshot:
          product.imageUrl || "",
      });
    }

    // TOTAL
    const income = items.reduce(
      (sum, i) =>
        sum +
        i.priceSnapshot * i.quantity,
      0
    );

    // SAVE ORDER
    const order = await Order.create({
      cartId,
      items,
      delivery,
      status: "pending",
      income,
    });

    // CLEAR CART
    await Cart.updateOne(
      { cartId },
      {
        $set: {
          items: [],
        },
      }
    );

    // PRODUCTS TEXT WITH IMAGE LINK
    const itemsText = items
      .map(
        (i) => `
• ${i.nameSnapshot}

Qty: ${i.quantity}

Price: ${
          i.priceSnapshot * i.quantity
        }

Image: ${process.env.BACKEND_URL}${i.imageUrlSnapshot}
`
      )
      .join("\n");

    // WHATSAPP MESSAGE
    const whatsappMessage = `
🛒 *New Order*

👤 Name: ${delivery.fullName}

📞 Phone: ${delivery.phone}

📍 Address: ${delivery.addressLine1}

🏙 City: ${delivery.city}

🌍 Country: ${delivery.country}

📦 Products:
${itemsText}

💰 Total: ${income}

🆔 Order ID:
${order._id}
`;

    res.status(201).json({
      message: "Order created",
      orderId: order._id,
      whatsappMessage,
    });
  } catch (error) {
    res.status(400).json({
      message: error.message,
    });
  }
};

module.exports = { checkout };