const mongoose = require("mongoose");
const writeLog = require("../logger");

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    console.log("MongoDB Connected");

    writeLog("MongoDB Connected Successfully");
  } catch (error) {
    console.log(error);

    writeLog(`MongoDB Error: ${error.message}`);

    process.exit(1);
  }
};

module.exports = connectDB;